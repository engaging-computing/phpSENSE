#!/bin/sh
java -jar Mandarin.jar
