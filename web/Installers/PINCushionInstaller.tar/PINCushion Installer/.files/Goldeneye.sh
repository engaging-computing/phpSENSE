#!/bin/bash
java -jar $HOME/PINCushion/GoldenEye_v1.jar

