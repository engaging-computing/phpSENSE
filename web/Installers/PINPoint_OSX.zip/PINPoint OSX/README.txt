PINPoint Software v5.0

Installation
------------
1) Run "Install Me First.mpkg"
2) You can put GoldenEye_v1.jar anywhere as long as you
   put the lib folder with it. I suggest you just put the 
   PINPoint OSX folder on your desktop. 
3) Run "GoldenEye_v1.jar" then select "Tools-> Update Conversions"

